
package com.ngsempire.tab;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Team;

public final class NGSTab extends JavaPlugin {
    private final MiniMessage mm = MiniMessage.miniMessage();

    @Override
    public void onEnable() {
        getCommand("ngstab").setExecutor((sender, command, label, args) -> {
            if (!sender.hasPermission("ngstab.admin")) {
                sender.sendMessage("§cNo permission.");
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                sender.sendMessage("§aNGS TAB reloaded.");
                updateAll();
                return true;
            }
            sender.sendMessage("§c/ngstab reload");
            return true;
        });

        Bukkit.getScheduler().runTaskTimer(this, this::updateAll, 0L, 20L);
        updateAll();
        getLogger().info("NGS TAB enabled.");
    }

    private void updateAll() {
        int online = Bukkit.getOnlinePlayers().size();
        int max = Bukkit.getMaxPlayers();

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendPlayerListHeaderAndFooter(
                mm.deserialize(
                    "<gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</gray>\n" +
                    "<red><bold>⚔ NGS EMPIRE ⚔</bold></red>\n" +
                    "<gold>Survival Network</gold> <gray>•</gray> <green>ONLINE</green>\n"
                ),
                mm.deserialize(
                    "<gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</gray>\n" +
                    "<gray>Online:</gray> <white>" + online + "/" + max + "</white>  " +
                    "<gray>Ping:</gray> <white>" + p.getPing() + "ms</white>\n" +
                    "<gray>World:</gray> <white>" + p.getWorld().getName() + "</white>\n" +
                    "<red>play.ngsempire.net</red>"
                )
            );

            p.setPlayerListName(Component.text(p.getName()));
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("NGS TAB disabled.");
    }
}
